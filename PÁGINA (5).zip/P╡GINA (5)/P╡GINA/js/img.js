header{
    height: 1000vh;
    background-image: linear-gradient(to top, rgba(35, 97, 146, 0.5)0%, rgba(134, 38, 51, 0.5)100%), url(IMAGENES/corona.jpg);

}

